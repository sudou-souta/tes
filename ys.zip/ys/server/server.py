import sqlite3
import os
import parse
import ip_socket
import server_socket
import req_create
import socket
home = os.environ["HOME"]

# server_socket
server = server_socket.server_socket()
# ip_socket
ip_socket = ip_socket.ip_socket()
# sqlite3
conn = sqlite3.connect(f"{home}/ys/db.sqlite");cur = conn.cursor()

while True:
    client,addr = server.accept()
    client.settimeout(1)  # タイムアウトを10秒に設定
    try:
        req = client.recv(4096)
        req = req.decode("utf-8")
        print(f"Received request: {req}")  # 追加
        if not req:
            pass
        else:
            req_overiview = parse.parser(req)
            if req_overiview == False:
                print("リクエストの形式が正しくありません")
            else:
                req_type = req_overiview[0]
                if req_type == "m":
                    # var
                    channel = req_overiview[1]
                    message = req_overiview[2]
                    print(f"Channel: {channel}, Message: {message}")  # 追加
                    # INSERT
                    cur.execute("INSERT INTO message(channel,message) VALUES(?,?)",(channel,message))
                    conn.commit()
                    print("追加しました")
                    # close
                    client.close()
                    conn.close()
                    # 伝搬
                    ip_socket_req = req_create.req_create_message(channel,message)
                    ip_socket.send(ip_socket_req)
                else:
                    pass
    except socket.timeout:
        client.close()