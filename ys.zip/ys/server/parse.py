def parser(req):
    # type;channel|message
    # type;query
    req = list(req)
    req_len = len(req)
    count = 0
    req_type = req[count]
    if req_type != "m":
        return False
    else:
        count += 1
        if req[count] != ";":
            return False
        else:
            count += 1
            channel = ""
            while True:
                string = req[count]
                if string == "|":
                    count += 1
                    break
                else:
                    channel += string
                    count += 1
            message = ""
            while True:
                if count == req_len:
                    break
                string = req[count]
                message += string
                count += 1
            return [req_type,channel,message]