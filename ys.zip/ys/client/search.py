import sqlite3
import os
import sys
# python3 client/search.py query

if len(sys.argv) != 2:
    print("引数が足りません")
    sys.exit(1)

query = sys.argv[1]
home = os.environ["HOME"]

conn = sqlite3.connect(f"{home}/ys/db.sqlite")
cur = conn.cursor()

cur.execute("SELECT * FROM img_buy WHERE title LIKE ?", ('%' + query + '%',))
res = cur.fetchall()
res_text = ""
for i in range(len(res)):
    channel = res[i][0]
    message = res[i][1]
    print(f"チャンネル:{channel},メッセージ:{message}")

